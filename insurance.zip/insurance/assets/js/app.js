// /assets/js/app.js
// =========================================================
// JS minimale per interazioni di base
// - Menu mobile (navbar)
// - Accordion FAQ
// - Validazione form
// =========================================================

document.addEventListener("DOMContentLoaded", () => {

  // ----------------------------
  // 1) Navbar toggle (mobile)
  // ----------------------------
  const navbars = document.querySelectorAll(".navbar");
  navbars.forEach(nav => {
    const toggle = nav.querySelector(".navbar__toggle");
    const menu = nav.querySelector(".navbar__menu");
    if (toggle && menu) {
      toggle.addEventListener("click", () => {
        const expanded = toggle.getAttribute("aria-expanded") === "true";
        toggle.setAttribute("aria-expanded", String(!expanded));
        nav.classList.toggle("is-open", !expanded);
      });
    }
  });

  // ----------------------------
  // 2) FAQ accordion
  // ----------------------------
  const accordions = document.querySelectorAll("[data-accordion]");
  accordions.forEach(acc => {
    const items = acc.querySelectorAll(".accordion__item");
    items.forEach(item => {
      const trigger = item.querySelector(".accordion__trigger");
      const panel = item.querySelector(".accordion__panel");
      if (trigger && panel) {
        trigger.addEventListener("click", () => {
          const isOpen = item.classList.contains("is-open");

          // Chiudi tutti
          items.forEach(i => {
            i.classList.remove("is-open");
            i.querySelector(".accordion__trigger").setAttribute("aria-expanded", "false");
          });

          // Apri se non era già aperto
          if (!isOpen) {
            item.classList.add("is-open");
            trigger.setAttribute("aria-expanded", "true");
          }
        });

        // Accessibilità tastiera
        trigger.addEventListener("keydown", e => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            trigger.click();
          }
        });
      }
    });
  });

  // ----------------------------
  // 3) Form validation
  // ----------------------------
  const forms = document.querySelectorAll("form");
  forms.forEach(form => {
    form.addEventListener("submit", e => {
      if (!form.checkValidity()) {
        e.preventDefault();
        form.querySelectorAll(":invalid")[0]?.focus();
      }
    });
  });

});
